from setuptools import setup

setup(name='prajwal_lib',
      version='0.2',
      description='lib to cheat in ml exam',
      packages=['prajwal_lib'],
      author_email='prajsa99@gmail.com',
      zip_safe=False)